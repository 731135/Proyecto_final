from django.urls import path
from consulta import views
from django.contrib.auth.decorators import login_required



urlpatterns = [
	path('list_medico_admin', login_required(views.list_medico_admin.as_view()), name = "list_medico_admin_views"),
	path('update_medico/<int:pk>/', login_required(views.update_medico.as_view()), name = "update_medico_views"),
	path('create_medico/',login_required(views.create_medico.as_view()), name = "create_medico_views"),
	path('delete_medico/<int:pk>/', login_required(views.delete_medico.as_view()), name = "delete_medico_views"),
	
	path('list_paciente_admin', login_required(views.list_paciente_admin.as_view()), name = "list_paciente_admin_views"),
	path('update_paciente/<int:pk>/',login_required(views.update_paciente.as_view()), name = "update_paciente_views"),
	path('create_paciente/',login_required(views.create_paciente.as_view()), name = "create_paciente_views"),
	path('delete_paciente/<int:pk>/', login_required(views.delete_paciente.as_view()), name = "delete_paciente_views"),

	path('list_consulta_admin', login_required(views.list_consulta_admin.as_view()), name = "list_consulta_admin_views"),
	path('update_consulta/<int:pk>/',login_required(views.update_consulta.as_view()), name = "update_consulta_views"),
	path('create_consulta/',login_required(views.create_consulta.as_view()), name = "create_consulta_views"),
	path('delete_consulta/<int:pk>/', login_required(views.delete_consulta.as_view()), name = "delete_consulta_views"),

	path('list_medico_consulta/', login_required(views.list_medico_consulta.as_view()), name = "list_medico_consulta_view"),
	path('list_medico_pacientes/', login_required(views.list_medico_pacientes.as_view()), name = "list_medico_pacientes_view"),
	path('create_consulta_user/',login_required(views.create_consulta_user.as_view()), name = "create_consulta_user_views"),
	path('create_paciente_user/',login_required(views.create_paciente_user.as_view()), name = "create_paciente_user_views"),

    path('detalle_consulta/<int:pk>/', login_required(views.detalle_consulta.as_view()), name = "detalle_consulta_views"),
    path('detalle_paciente/<int:pk>/', login_required(views.detalle_paciente.as_view()), name = "detalle_paciente_views"),

    path('detalle_consulta_admin/<int:pk>/', login_required(views.detalle_consulta_admin.as_view()), name = "detalle_consulta_admin_views"),
    path('detalle_paciente_admin/<int:pk>/', login_required(views.detalle_paciente_admin.as_view()), name = "detalle_paciente_admin_views"),
    path('detalle_medico_admin/<int:pk>/', login_required(views.detalle_medico_admin.as_view()), name = "detalle_medico_admin_views"),


	path('registro/',views.registro.as_view(), name = "registro_views"),
    path('list_hub', login_required(views.list_hub.as_view()), name = "list_hub_views"),
]
