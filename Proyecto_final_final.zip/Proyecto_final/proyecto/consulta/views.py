from django.shortcuts import render
from .models import paciente, consul, medico
from django.views import generic
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q

from .forms import Registro
# Create your views here.

#Pantallas de administrador
#Pantalla de medico
class list_medico_admin(generic.ListView):
	template_name = "admin/medicos.html"
	model = medico
	
class update_medico(generic.UpdateView):
    template_name = "admin/update/medicos.html"
    model = medico
    fields = ["nombre_M","apP_M","apM_M","fecha_nac_M","genero_M","civil_M","direccion","telefono_M","correo_M"]
    success_url = "/consulta/list_medico_admin"
	
class create_medico(generic.CreateView):
    template_name = "admin/create/medicos.html"
    queryset = medico.objects.all() 
    fields = ["Id_M","nombre_M","apP_M","apM_M","fecha_nac_M","genero_M","civil_M","direccion","telefono_M","correo_M"]
    success_url = "/consulta/list_medico_admin"	

class delete_medico(generic.DeleteView):
    template_name = "admin/delete/delete.html"
    model = medico
    success_url = "/consulta/list_medico_admin"

class detalle_consulta_admin(generic.DetailView):
    template_name = "admin/detail/consultas.html"
    model = consul

class detalle_paciente_admin(generic.DetailView):
    template_name = "admin/detail/pacientes.html"
    model = paciente

class detalle_medico_admin(generic.DetailView):
    template_name = "admin/detail/medicos.html"
    model = medico



#Pantalla de paciente
class list_paciente_admin(generic.ListView):
	template_name = "admin/pacientes.html"
	model = paciente	
	
class update_paciente(generic.UpdateView):
	template_name = "admin/update/pacientes.html"
	model = paciente
	fields = ["nombre_P","apP_P","apM_P","direccion_P","CP","telefono_P","genero_P","civil_P","correo_P","tipoS","alergias"]
	success_url = "/consulta/list_paciente_admin"
	
class create_paciente(generic.CreateView):
    template_name = "admin/create/pacientes.html"
    queryset = paciente.objects.all() 
    fields = ["nombre_P","apP_P","apM_P","direccion_P","CP","telefono_P","genero_P","civil_P","correo_P","tipoS","alergias","fecha_nac"]
    success_url = "/consulta/list_paciente_admin"	

class delete_paciente(generic.DeleteView):
    template_name = "admin/delete/delete.html"
    model = paciente
    success_url = "/consulta/list_paciente_admin"




#Pantalla de consulta
class list_consulta_admin(generic.ListView):
	template_name = "admin/consultas.html"
	model = consul

class update_consulta(generic.UpdateView):
	template_name = "admin/update/consultas.html"
	model = consul
	fields = ["observaciones","diagnostico"]
	success_url = "/consulta/list_consulta_admin"

class create_consulta(generic.CreateView):
    template_name = "admin/create/consultas.html"
    queryset = consul.objects.all() 
    fields = ["id_C","id_p","id_M","peso","altura","presion_A","frecuencia_R","temperatura","frecuencia_C","diagnostico"]
    success_url = "/consulta/list_consulta_admin"	

class delete_consulta(generic.DeleteView):
    template_name = "admin/delete/delete.html"
    model = consul
    success_url = "/consulta/list_consulta_admin"


#Pantallas de usuarios
class list_medico_consulta(generic.ListView):
    template_name = "usuarios/medico_consulta.html"
    model = consul

    def get_queryset(self, *args, **kwargs):
        qs = consul.objects.all()
        print(self.request.GET)
        query = self.request.GET.get("q",None)
        if query is not None:
            qs=qs.filter(id_C__icontains=query)
            print(qs)
        return qs
    

class list_medico_pacientes(generic.ListView):
    template_name = "usuarios/medico_paciente.html"
    model = paciente

    def get_queryset(self, *args, **kwargs):
        qs = paciente.objects.all()
        print(self.request.GET)
        query = self.request.GET.get("q",None)
        if query is not None:
            qs=qs.filter(Q(nombre_P__icontains=query) | Q(apP_P__icontains=query) | Q(apM_P__icontains=query))
            print(qs)
        return qs

class create_consulta_user(generic.CreateView):
    template_name = "usuarios/creates/consultas.html"
    queryset = consul.objects.all() 
    fields = ["id_C","id_p","id_M","peso","altura","presion_A","frecuencia_R","temperatura","frecuencia_C","diagnostico"]
    success_url = "/consulta/list_medico_consulta"

class create_paciente_user(generic.CreateView):
    template_name = "usuarios/creates/pacientes.html"
    queryset = paciente.objects.all() 
    fields = ["nombre_P","apP_P","apM_P","direccion_P","CP","telefono_P","genero_P","civil_P","correo_P","tipoS","alergias","fecha_nac"]
    success_url = "/consulta/list_medico_pacientes"	
    
class registro(generic.CreateView):
    model = User
    template_name = "registration/create_user.html"
    form_class = Registro
    success_url = "/accounts/login"

class detalle_consulta(generic.DetailView):
    template_name = "usuarios/detail/consultas.html"
    model = consul

class detalle_paciente(generic.DetailView):
    template_name = "usuarios/detail/pacientes.html"
    model = paciente
    
class list_hub(generic.ListView):
	template_name = "home/hub.html"
	model = User



















