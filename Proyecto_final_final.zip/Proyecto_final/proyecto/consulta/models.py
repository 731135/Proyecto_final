from django.db import models
from django.conf import settings


GENDER_CHOICES = (
('masculino', 'M'),
('femenino', 'F'),
)

CIVIL_CHOICES = (
('soltero', 'Soltero'),
('casado', 'Casado'),
('viudo','Viudo' ),
)

BLOOD_CHOICES = (
('op','O+'),
('on','O-'),
('ap', 'A+'),
('an','A-'),
('bp','B+'),
('bn','B-'),
('abp','AB+'),
('abn','AB-'),
)

# Create your models here.
class paciente(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE)  
    nombre_P = models.CharField(max_length=20, default="")
    apP_P = models.CharField(max_length=20, default="")
    apM_P = models.CharField(max_length=20, default="")
    direccion_P = models.CharField(max_length=250, default="")
    CP = models.CharField(max_length=5, default="")
    telefono_P = models.CharField(max_length=10, default="")
    genero_P = models.CharField(max_length=20,choices = GENDER_CHOICES, default="")
    civil_P = models.CharField(max_length=20,choices = CIVIL_CHOICES, default="")
    correo_P = models.CharField(max_length=30, default="")
    tipoS = models.CharField(max_length=20,choices = BLOOD_CHOICES, default="")
    alergias = models.CharField(max_length=250, default="")
    fecha_nac = models.DateField()



    def __str__(self):
        return str(self.nombre_P)



class consul(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE)  
    id_C= models.CharField(max_length=3, default="")
    peso = models.CharField(max_length=9, default="")
    altura = models.CharField(max_length=9, default="")
    presion_A = models.CharField(max_length=9, default="")
    frecuencia_R = models.CharField(max_length=9, default="")
    temperatura = models.CharField(max_length=9, default="")
    frecuencia_C = models.CharField(max_length=9, default="")
    Sintomas = models.TextField(max_length=255, default="")
    observaciones = models.TextField(max_length=255, default="")
    diagnostico = models.CharField(max_length=255, default="")
    timestamp = models.DateTimeField(auto_now_add = True)
    id_p = models.ForeignKey('paciente', on_delete=models.CASCADE, default = "")
    id_M = models.ForeignKey('medico', on_delete = models.CASCADE, default = "")


    def __str__(self):
        return str(self.id_C)



class medico(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE) 
    Id_M = models.CharField(max_length=3, default="")
    nombre_M = models.CharField(max_length = 20 , default="")
    apP_M = models.CharField(max_length=20, default="")
    apM_M = models.CharField(max_length=20, default="")
    genero_M = models.CharField(max_length=20,choices = GENDER_CHOICES, default="")
    civil_M = models.CharField(max_length=20,choices = CIVIL_CHOICES, default="")
    direccion = models.CharField(max_length=250, default="")
    telefono_M = models.CharField(max_length=10, default="")
    correo_M = models.CharField(max_length=30, default="")
    fecha_nac_M = models.DateField()
    usuario = models.CharField(max_length=30, default="")
    password = models.CharField(max_length=30, default="")

    def __str__(self):
        return str(self.nombre_M)

























   
